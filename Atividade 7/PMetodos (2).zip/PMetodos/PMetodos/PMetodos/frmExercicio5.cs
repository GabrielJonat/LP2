﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            int numero;
            if (!int.TryParse(txtNum1.Text, out numero))
            {
                MessageBox.Show("Insira um número!");
                txtNum1.Focus();
            }
        }

        private void TxtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            int numero;
            if (!int.TryParse(txtNum2.Text, out numero))
            {
                MessageBox.Show("Insira um número inteiro!");
                txtNum2.Focus();
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = int.Parse(txtNum1.Text);
            num2 = int.Parse(txtNum2.Text);
            Random sorteio = new Random();
            int numero = sorteio.Next(num1,num2);
            MessageBox.Show($"O número sorteado foi: {numero}");
        }

        private void Button1_Validated(object sender, EventArgs e)
        {
            if (int.Parse(txtNum1.Text) >= int.Parse(txtNum2.Text)) {
                MessageBox.Show("O primeiro número deve ser menor do que o primeiro!");
            }
        }
    }
}
