﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int position = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            while (position >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Remove(position, txtPalavra1.Text.Length);
                position = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            txtPalavra2.Text = "";
            foreach (var i in vetor) {
                txtPalavra2.Text += i;
            }
        }
    }
}
