﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i = 0; i < richTextFrase.Text.Length; i++) {
                if (char.IsLetter(richTextFrase.Text[i])) {
                    contador++;
                }
     
            }
            MessageBox.Show($"O Número de caracteres alphabéticos: {contador}");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (var c in richTextFrase.Text) {
                if (char.IsNumber(c))
                    cont++;
            }
            MessageBox.Show($"Número de caracteres númericos: {cont}");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int cont = 0;
            if (richTextFrase.Text.Length > 0)
            {
                while (richTextFrase.Text[cont] != ' ' && cont < richTextFrase.Text.Length - 1)
                {
                    cont++;
                }
                if (cont + 1== richTextFrase.Text.Length)
                    MessageBox.Show("Não há espaços em branco na frase!");
                else
                    MessageBox.Show($"Posição do primeiro espaço em branco: {cont + 1}");
            }
            else
                MessageBox.Show("Não há espaços em branco na frase!");
        }
    }
}
