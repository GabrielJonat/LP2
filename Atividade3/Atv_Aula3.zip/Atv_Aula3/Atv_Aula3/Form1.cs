﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atv_Aula3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPeso, "");
            if(!Double.TryParse(mskbxPeso.Text,out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso Inválido!");
                errorProvider1.SetError(mskbxPeso, "peso inválido");
            }
        }

        private void MskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MskbxAltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider2.SetError(mskbxAltura, "");
            if (!Double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida!");
                errorProvider2.SetError(mskbxPeso, "altura inválida!");
            }
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;
            if(Double.TryParse(mskbxPeso.Text, out peso) && Double.TryParse(mskbxAltura.Text, out altura))
            {
                if ((altura < 0) || (peso < 0))
                    MessageBox.Show("Valores precisam ser maiores do que zero!");
                else
                {
                    imc = peso / (altura * altura);
                    imc = Math.Round(imc, 1);
                    txtIMC.Text = imc.ToString();
                    if (imc < 18.5)
                        txtIMC.Text += "Classificação: magreza";
                    else if (imc <= 24.9)
                        MessageBox.Show("IMC: "+txtIMC.Text+" Classificação: Normal");
                    else if (imc <= 29.9)
                        MessageBox.Show(txtIMC.Text + " Classificação: Sobrepeso");
                    else if (imc <= 39.9)
                        MessageBox.Show(txtIMC.Text + " Classificação: Obesidade");
                    else
                        MessageBox.Show(txtIMC.Text + " Classificação: Obesidade Mórbida");
                }
            }
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtIMC.Clear();
        }

        private void BtnOut_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
