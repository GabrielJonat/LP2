﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4_Triângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtL1_Validated(object sender, EventArgs e)
        {
            double lado1;
            if (!Double.TryParse(txtL1.Text, out lado1) || lado1 <= 0)
            {
                MessageBox.Show("Número inválido");
                txtL1.Focus();
            }
        }

        private void txtL2_Validated(object sender, EventArgs e)
        {
            double lado2;
            if (!Double.TryParse(txtL2.Text, out lado2) || lado2 <= 0)
            {
                MessageBox.Show("Número inválido");
                txtL2.Focus();
            }
        }

        private void txtL3_Validated(object sender, EventArgs e)
        {
            double lado3;
            if (!Double.TryParse(txtL3.Text, out lado3) || lado3 <= 0)
            {
                MessageBox.Show("Número inválido");
                txtL3.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double lado1, lado2, lado3, maior,perimetro;
            lado1 = Double.Parse(txtL1.Text);
            lado2 = Double.Parse(txtL2.Text);
            lado3 = Double.Parse(txtL3.Text);
            maior = lado1;
            if (maior < lado2)
                maior = lado2;
            else
                if (maior < lado3)
                maior = lado3;
            if (maior >= lado1 + lado2 + lado3 - maior)
            {
                txtClass.Text = "Não forma triângulo!";
                MessageBox.Show(txtClass.Text);
            }
            else
            {
                perimetro = lado1 + lado2 + lado3;
                if (lado1.Equals(lado2) && lado1.Equals(lado3))
                {
                    txtClass.Text = "Triangulo Equilatero";
                    MessageBox.Show(txtClass.Text+" Perímetro: "+perimetro.ToString());
                }
                else
                if ((lado1.Equals(lado2) || lado2.Equals(lado3) || lado1.Equals(lado3)))
                {
                    txtClass.Text = "Triangulo Isóceles";
                    MessageBox.Show(txtClass.Text + " Perímetro: " + perimetro.ToString());
                }
                else
                    txtClass.Text = "Triangulo Escaleno";
                    MessageBox.Show(txtClass.Text + " Perímetro: " + perimetro.ToString());
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtClass.Clear();
            txtL1.Clear();
            txtL2.Clear();
            txtL3.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
