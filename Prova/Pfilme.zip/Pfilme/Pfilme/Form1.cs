﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace Pfilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {
            Lstbx.Items.Clear();
            double[,] notas = new double[2, 2];
            int i, j;
            string aux = "";
            for (i = 0; i <= 1; i++)
                for (j = 0; j <= 1; j++) {
                    aux = Interaction.InputBox($"Digite a nota do filme {j+1}: ", "Entrada de Dados", "");
                    if (!Double.TryParse(aux, out notas[i, j]) || notas[i,j] > 10 || notas[i,j] < 0)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                        notas[i, j] = double.Parse(aux);
                }
            double soma = 0, media;
       
            for (i = 0; i <= 1; i++)
            {
                if(i == 0)
                    aux = $"Pessoa{i + 1} Nota Filme {i + 1}: {notas[i, i]} Nota Filme {i+2}: {notas[i, i + 1]}";
                else
                    aux = $"Pessoa{i + 1} Nota Filme {i }: {notas[i, i-1]} Nota Filme{i+1}: {notas[i, i]}";
                Lstbx.Items.Add(aux);
            }
            Lstbx.Items.Add("--------------");
            for (i = 0; i <= 1; i++)
                for (j = 0; j <= 1; j++)
                {

                    soma += notas[i, j];
                    if (j == 1)
                    {
                        media = soma / 2;
                        soma = 0;
                        Lstbx.Items.Add($"Média Filme {i + 1}: {media.ToString("F")}");
                    }
                    
                }
          
        }
    }
}
