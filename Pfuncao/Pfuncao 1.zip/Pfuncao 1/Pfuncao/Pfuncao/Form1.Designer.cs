﻿namespace Pfuncao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnReturnPar = new System.Windows.Forms.Button();
            this.btnNoreturn = new System.Windows.Forms.Button();
            this.btnNoRetunPar = new System.Windows.Forms.Button();
            this.outNoReturn = new System.Windows.Forms.Button();
            this.OutReturn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(198, 103);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(133, 80);
            this.btnReturn.TabIndex = 2;
            this.btnReturn.Text = "Com Retorno";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // btnReturnPar
            // 
            this.btnReturnPar.Location = new System.Drawing.Point(599, 103);
            this.btnReturnPar.Name = "btnReturnPar";
            this.btnReturnPar.Size = new System.Drawing.Size(133, 80);
            this.btnReturnPar.TabIndex = 4;
            this.btnReturnPar.Text = "Com Retorno e com Parâmetros";
            this.btnReturnPar.UseVisualStyleBackColor = true;
            this.btnReturnPar.Click += new System.EventHandler(this.BtnReturnPar_Click);
            // 
            // btnNoreturn
            // 
            this.btnNoreturn.Location = new System.Drawing.Point(12, 103);
            this.btnNoreturn.Name = "btnNoreturn";
            this.btnNoreturn.Size = new System.Drawing.Size(133, 80);
            this.btnNoreturn.TabIndex = 1;
            this.btnNoreturn.Text = "Sem Retorno";
            this.btnNoreturn.UseVisualStyleBackColor = true;
            this.btnNoreturn.Click += new System.EventHandler(this.BtnNoreturn_Click);
            // 
            // btnNoRetunPar
            // 
            this.btnNoRetunPar.Location = new System.Drawing.Point(387, 103);
            this.btnNoRetunPar.Name = "btnNoRetunPar";
            this.btnNoRetunPar.Size = new System.Drawing.Size(133, 80);
            this.btnNoRetunPar.TabIndex = 3;
            this.btnNoRetunPar.Text = "Sem Retorno e com Parâmetros";
            this.btnNoRetunPar.UseVisualStyleBackColor = true;
            this.btnNoRetunPar.Click += new System.EventHandler(this.BtnNoRetunPar_Click);
            // 
            // outNoReturn
            // 
            this.outNoReturn.Location = new System.Drawing.Point(198, 214);
            this.outNoReturn.Name = "outNoReturn";
            this.outNoReturn.Size = new System.Drawing.Size(133, 80);
            this.outNoReturn.TabIndex = 5;
            this.outNoReturn.Text = "Out Sem Retorno";
            this.outNoReturn.UseVisualStyleBackColor = true;
            this.outNoReturn.Click += new System.EventHandler(this.OutNoReturn_Click);
            // 
            // OutReturn
            // 
            this.OutReturn.Location = new System.Drawing.Point(387, 214);
            this.OutReturn.Name = "OutReturn";
            this.OutReturn.Size = new System.Drawing.Size(133, 80);
            this.OutReturn.TabIndex = 6;
            this.OutReturn.Text = "Out com Retorno";
            this.OutReturn.UseVisualStyleBackColor = true;
            this.OutReturn.Click += new System.EventHandler(this.OutReturn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(293, 320);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 80);
            this.button1.TabIndex = 7;
            this.button1.Text = "Data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.OutReturn);
            this.Controls.Add(this.outNoReturn);
            this.Controls.Add(this.btnNoRetunPar);
            this.Controls.Add(this.btnNoreturn);
            this.Controls.Add(this.btnReturnPar);
            this.Controls.Add(this.btnReturn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnReturnPar;
        private System.Windows.Forms.Button btnNoreturn;
        private System.Windows.Forms.Button btnNoRetunPar;
        private System.Windows.Forms.Button outNoReturn;
        private System.Windows.Forms.Button OutReturn;
        private System.Windows.Forms.Button button1;
    }
}

