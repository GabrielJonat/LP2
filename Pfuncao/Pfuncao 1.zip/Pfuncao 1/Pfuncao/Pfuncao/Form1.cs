﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pfuncao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        void Soma1() {
            Double resultado = 4 + 3;
            MessageBox.Show($"O resultado é: {resultado.ToString()}");
        }
        double Soma2() {
            Double resultado = 4 + 3;
            return resultado;
        }
        void Soma3(double x, double y) {
            Double resultado = 4 + 3;
            MessageBox.Show($"O resultado é: {resultado}");
        }
        double Soma4(ref double x, double y)
        {
            x = 10;
            Double resultado = x + y;
            return resultado;
        }

        private void BtnNoreturn_Click(object sender, EventArgs e)
        {
            Soma1();
        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            double retorno = Soma2();
            MessageBox.Show(retorno.ToString());
        }

        private void BtnNoRetunPar_Click(object sender, EventArgs e)
        {
            double x = 4, y = 3;
            Soma3(x,y);
        }

        private void BtnReturnPar_Click(object sender, EventArgs e)
        {
            double x = 3, y = 4;
            double resultado = Soma4(ref x, y);
            MessageBox.Show(resultado.ToString());
            MessageBox.Show(x.ToString());
        }
        void Soma7(out double resultado) {
            resultado = 4 + 3;
            MessageBox.Show($"O resultado é: {resultado.ToString()}");
        }
        Boolean Soma8(out double resultado) {
            resultado = 4 + 3;
            return true;
        }

        private void OutNoReturn_Click(object sender, EventArgs e)
        {
            double resultado;
            Soma7(out resultado);
        }

        private void OutReturn_Click(object sender, EventArgs e)
        {
            double resultado;
            bool volta = Soma8(out resultado);
            MessageBox.Show(resultado.ToString());
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            MessageBox.Show("Soma 2 dias: " + dt.AddDays(2).ToShortDateString());
            MessageBox.Show("Soma 2 horas: " + dt.AddHours(2).ToLongTimeString());
            MessageBox.Show("Dia da semana: " + dt.DayOfWeek.ToString());
            MessageBox.Show("Dias no mês 2/2000: " + DateTime.DaysInMonth(2000,2));
            DateTime dt2 = Convert.ToDateTime("01/02/2023");
            DateTime dt1 = Convert.ToDateTime("23/10/2023");
            double dias = dt1.Subtract(dt2).TotalDays;
            MessageBox.Show($"Diferença entre {dt1.ToShortDateString()} e {dt2.ToShortDateString()}: {dias.ToString()}");
        }
    }
}
