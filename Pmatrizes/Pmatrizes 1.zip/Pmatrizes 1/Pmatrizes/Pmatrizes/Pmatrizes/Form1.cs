﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            string aux = "",saida ="";
            int[] vetor = new int[20];
            for (var i = 0; i <= 19; i++) {
                aux = Interaction.InputBox("Digite um número", "Entrada de Dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
                else
                    saida = vetor[i] + "\n" + saida;
            }
            MessageBox.Show(saida);
            Array.Reverse(vetor);
            aux = "";
            foreach (var c in vetor) {
                aux += c;
            }
            MessageBox.Show(aux);
        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            double[,] medias = new double[20, 3];
            string aux = "";
            double media,soma=0;
            ArrayList medAluno = new ArrayList();
            for (var i = 0; i <= 2; i++)
                for (var j = 0; j <= 2; j++) {
                    aux = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ","Entrada de Dados");
                    if (!double.TryParse(aux, out medias[i, j]) || Double.Parse(aux) > 10 || Double.Parse(aux) < 0)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else {
                        if (j < 2)
                            soma += medias[i, j];
                        else {
                            soma += medias[i, j];
                            media = soma / 3.0;
                            medAluno.Add(media);
                            soma = 0;
                        }
                    }
                }
            foreach (var ele in medAluno)
            {
                MessageBox.Show("Média do aluno " + (medAluno.IndexOf(ele)+1).ToString()+": "+Math.Round((double)ele,2).ToString());
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");
            nomes.Remove("Otávio");
            string imprime = "";
            foreach (var objct in nomes) {
                imprime+= objct.ToString() + "\n";
            }
            MessageBox.Show(imprime);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            String[] vect = new string[2];
            string aux = "";
            bool temNum = false;
            for (var i = 0; i < 2; i++)
            {
                aux = Interaction.InputBox("Informe um nome: ", "Entrada de Dados");
                foreach (char ele in aux) {
                    if (char.IsNumber(ele))
                    {
                        temNum = true;
                        MessageBox.Show("O nome não deve conter caracteres numéricos!");
                        break;
                    }
                }
                while(temNum == true) {
                    aux = Interaction.InputBox("Informe um nome: ", "Entrada de Dados");
                    foreach (var ele in aux)
                    {
                        if (char.IsNumber(ele))
                        {
                            temNum = true;
                            break;
                        }
                        else
                            temNum = false;
                    }
                }
                vect[i] = aux;
            }
            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                MessageBox.Show("Forms já existe!");
                Application.OpenForms["Form2"].Activate();
            }
            Form2 frm2 = new Form2();
            frm2.WindowState = FormWindowState.Maximized;
            frm2.AddListBox(vect);
            frm2.Show();
        }
    }
}
