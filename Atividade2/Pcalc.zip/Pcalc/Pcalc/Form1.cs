﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1, num2,result;

        private void Lbl1_Validated(object sender, EventArgs e)
        {

        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            result = num1 + num2;
            txt3.Text = result.ToString();
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            result = num1 - num2;
            txt3.Text = result.ToString();
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txt3.Text = result.ToString();
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Impossível Calcular!","Divisão por zero",MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt2.Focus();
            }
            else
            {
                result = num1 / num2;
                txt3.Text = result.ToString();
            }
        }

        private void Btn2_Click(object sender, EventArgs e)
        {

        }

        private void Txt1_Validated(object sender, EventArgs e)
        {
           if(!Double.TryParse(txt1.Text,out num1))
            {
                MessageBox.Show("Número Inválido!");
                txt1.Focus();
            }
        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt2.Text, out num2))
            {
                MessageBox.Show("Número Inválido!");
                txt2.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt1.Focus();
        }
    }
}
