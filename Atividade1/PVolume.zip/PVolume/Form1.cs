﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double Raio, Altura, Volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            Volume = Math.PI * Math.Pow(Raio, 2) * Altura;
            txtVolume.Text = Volume.ToString("N2");
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void TxtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida!");
                txtAltura.Focus();
            }
            else
            {
                if (Altura <= 0)
                {
                    MessageBox.Show("Altura inválida!");
                    txtAltura.Focus();
                }
            }
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out Raio)) 
            {
                MessageBox.Show("Raio Inválido!");
                txtRaio.Focus();
            }
            else
            {
                if (Raio <= 0)
                {
                    MessageBox.Show("O Raio não pode ser zero!");
                    txtRaio.Focus();
                }
            }
        }
    }
}
