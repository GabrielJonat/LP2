﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Mskbx_Validated(object sender, EventArgs e)
        {
            double salBruto;
            errorProvider1.SetError(mskbx, "");
            if (!Double.TryParse(mskbx.Text,out salBruto) || salBruto == 0)
            {
                MessageBox.Show("Salário Inválido!");
                errorProvider1.SetError(mskbx, "Salário Inválido");
            }
        }

        private void TxtNome_Validated(object sender, EventArgs e)
        {
            int flag = 0;
            foreach (char i in txtNome.Text)
            {
                if(i>=48 && i <= 57)
                {
                    flag += 1;
                    break;
                }
            }
            if (flag == 1)
            {
                MessageBox.Show("Não insira números na seção nome!");
                txtNome.Focus();
            }
        }

        private void BtnVer_Click(object sender, EventArgs e)
        {
            double salBruto, descINSS, descIRPF;
            salBruto = Double.Parse(mskbx.Text);
            if (salBruto <= 800.47)
            {
                txtAlINSS.Text = "7.65%";
                txtDescINSS.Text = Math.Round((salBruto * 0.0765),2).ToString();
            }
            else
            if (salBruto <= 1050)
            {
                txtAlINSS.Text = "8.65%";
                txtDescINSS.Text = Math.Round((salBruto * 0.0865),2).ToString();
            }
            else
             if (salBruto <= 1400.77)
            {
                txtAlINSS.Text = "9%";
                txtDescINSS.Text = Math.Round((salBruto * 0.09),2).ToString();
            }
            else
             if (salBruto <= 2801.56)
            {
                txtAlINSS.Text = "11%";
                txtDescINSS.Text = Math.Round((salBruto * 0.11),2).ToString();
            }
            else
            {
                txtAlINSS.Text = "teto";
                txtDescINSS.Text = Math.Round((308.17),2).ToString();
            }
            if (salBruto <= 1257.12)
            {
                txtAlIRPF.Text = "isento";
                txtDescIRPF.Text = "0";
            }
            else
            {
                if (salBruto <= 2512.08)
                {
                    txtAlIRPF.Text = "15.00%";
                    txtDescIRPF.Text = Math.Round((salBruto * 0.15)).ToString();
                }
                else
                {
                    txtAlIRPF.Text = "27.5%";
                    txtDescIRPF.Text = Math.Round((salBruto * 0.275),2).ToString();
                }
            }
            if (salBruto <= 435.52)
                txtSalFamilia.Text = Math.Round((Decimal.ToDouble(valFilhos.Value) * 22.33), 2).ToString();
            else
            {
                if (salBruto <= 654.61)
                    txtSalFamilia.Text = (Decimal.ToDouble(valFilhos.Value) * 15.74).ToString();
                else
                    txtSalFamilia.Text = "0";
            }
            descINSS = Double.Parse(txtDescINSS.Text);
            descIRPF = Double.Parse(txtDescIRPF.Text);
            txtSalLiquido.Text = Math.Round((salBruto - descIRPF - descINSS + double.Parse(txtSalFamilia.Text)),2).ToString();
        }

        private void TxtNome_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
