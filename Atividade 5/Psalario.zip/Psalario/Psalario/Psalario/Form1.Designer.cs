﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtAlINSS = new System.Windows.Forms.TextBox();
            this.txtAlIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblAlINSS = new System.Windows.Forms.Label();
            this.lblAlIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDescontINSS = new System.Windows.Forms.Label();
            this.lblDescontIRPF = new System.Windows.Forms.Label();
            this.btnVer = new System.Windows.Forms.Button();
            this.lblNumFio = new System.Windows.Forms.Label();
            this.valFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskbx = new System.Windows.Forms.MaskedTextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.valFilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(149, 12);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(504, 20);
            this.txtNome.TabIndex = 0;
            this.txtNome.TextChanged += new System.EventHandler(this.TxtNome_TextChanged);
            this.txtNome.Validated += new System.EventHandler(this.TxtNome_Validated);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtAlINSS
            // 
            this.txtAlINSS.Enabled = false;
            this.txtAlINSS.Location = new System.Drawing.Point(149, 198);
            this.txtAlINSS.Name = "txtAlINSS";
            this.txtAlINSS.Size = new System.Drawing.Size(141, 20);
            this.txtAlINSS.TabIndex = 3;
            // 
            // txtAlIRPF
            // 
            this.txtAlIRPF.Enabled = false;
            this.txtAlIRPF.Location = new System.Drawing.Point(149, 247);
            this.txtAlIRPF.Name = "txtAlIRPF";
            this.txtAlIRPF.Size = new System.Drawing.Size(141, 20);
            this.txtAlIRPF.TabIndex = 4;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(149, 305);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(141, 20);
            this.txtSalFamilia.TabIndex = 5;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(149, 372);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(141, 20);
            this.txtSalLiquido.TabIndex = 6;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(497, 198);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(141, 20);
            this.txtDescINSS.TabIndex = 7;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(497, 247);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(141, 20);
            this.txtDescIRPF.TabIndex = 8;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(40, 15);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(93, 13);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome Funcionário";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(40, 50);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(67, 13);
            this.lblSal.TabIndex = 2;
            this.lblSal.Text = "Salário Bruto";
            // 
            // lblAlINSS
            // 
            this.lblAlINSS.AutoSize = true;
            this.lblAlINSS.Location = new System.Drawing.Point(62, 201);
            this.lblAlINSS.Name = "lblAlINSS";
            this.lblAlINSS.Size = new System.Drawing.Size(75, 13);
            this.lblAlINSS.TabIndex = 11;
            this.lblAlINSS.Text = "Alíquota INSS";
            // 
            // lblAlIRPF
            // 
            this.lblAlIRPF.AutoSize = true;
            this.lblAlIRPF.Location = new System.Drawing.Point(62, 250);
            this.lblAlIRPF.Name = "lblAlIRPF";
            this.lblAlIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblAlIRPF.TabIndex = 12;
            this.lblAlIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(62, 308);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalFamilia.TabIndex = 13;
            this.lblSalFamilia.Text = "Salario Familia";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(62, 375);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiquido.TabIndex = 14;
            this.lblSalLiquido.Text = "Salario Líquido";
            // 
            // lblDescontINSS
            // 
            this.lblDescontINSS.AutoSize = true;
            this.lblDescontINSS.Location = new System.Drawing.Point(410, 201);
            this.lblDescontINSS.Name = "lblDescontINSS";
            this.lblDescontINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescontINSS.TabIndex = 15;
            this.lblDescontINSS.Text = "Desconto INSS";
            // 
            // lblDescontIRPF
            // 
            this.lblDescontIRPF.AutoSize = true;
            this.lblDescontIRPF.Location = new System.Drawing.Point(410, 250);
            this.lblDescontIRPF.Name = "lblDescontIRPF";
            this.lblDescontIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescontIRPF.TabIndex = 16;
            this.lblDescontIRPF.Text = "Desconto IRPF";
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(329, 125);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(115, 37);
            this.btnVer.TabIndex = 17;
            this.btnVer.Text = "Verifica Desconto";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.BtnVer_Click);
            // 
            // lblNumFio
            // 
            this.lblNumFio.AutoSize = true;
            this.lblNumFio.Location = new System.Drawing.Point(40, 97);
            this.lblNumFio.Name = "lblNumFio";
            this.lblNumFio.Size = new System.Drawing.Size(86, 13);
            this.lblNumFio.TabIndex = 18;
            this.lblNumFio.Text = "Número de filhos";
            // 
            // valFilhos
            // 
            this.valFilhos.Location = new System.Drawing.Point(149, 95);
            this.valFilhos.Maximum = new decimal(new int[] {
            70,
            0,
            0,
            0});
            this.valFilhos.Name = "valFilhos";
            this.valFilhos.Size = new System.Drawing.Size(120, 20);
            this.valFilhos.TabIndex = 3;
            // 
            // mskbx
            // 
            this.mskbx.Location = new System.Drawing.Point(149, 47);
            this.mskbx.Mask = "999999.99";
            this.mskbx.Name = "mskbx";
            this.mskbx.Size = new System.Drawing.Size(149, 20);
            this.mskbx.TabIndex = 2;
            this.mskbx.Validated += new System.EventHandler(this.Mskbx_Validated);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mskbx);
            this.Controls.Add(this.valFilhos);
            this.Controls.Add(this.lblNumFio);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.lblDescontIRPF);
            this.Controls.Add(this.lblDescontINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAlIRPF);
            this.Controls.Add(this.lblAlINSS);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAlIRPF);
            this.Controls.Add(this.txtAlINSS);
            this.Controls.Add(this.txtNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.valFilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtAlINSS;
        private System.Windows.Forms.TextBox txtAlIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblAlINSS;
        private System.Windows.Forms.Label lblAlIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDescontINSS;
        private System.Windows.Forms.Label lblDescontIRPF;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Label lblNumFio;
        private System.Windows.Forms.NumericUpDown valFilhos;
        private System.Windows.Forms.MaskedTextBox mskbx;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

