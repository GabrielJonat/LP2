﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PDESPESA0030482311013
{

    class Tipo
    {
        //atributos
        private int idtipo; //td minusculo mas na propriedade maiusculo p n dar conflito
        private string descricaotipo;

        //propriedades
        public int Idtipo
        {
            get
            {
                return idtipo;
            }
            set
            {
                idtipo = value;
            }
        }
        public string Descricaotipo
        {
            get
            {
                return descricaotipo;
            }
            set
            {
                descricaotipo = value;
            }
        }
        public DataTable Listar()
        {
            SqlDataAdapter daTipo;
            DataTable dtTipo = new DataTable();
            try
            {
                daTipo = new SqlDataAdapter("SELECT  * FROM TIPO", frmPrincipal.conexao);
                daTipo.Fill(dtTipo);
                daTipo.FillSchema(dtTipo, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtTipo;
        }
            
    }
}
